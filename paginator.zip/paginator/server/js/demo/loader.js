/**
 * Created by Leon Cutler on 11/12/14.
 * Description:
 *
 */
define([
    'server/js/demo/directive'
], function () {
});