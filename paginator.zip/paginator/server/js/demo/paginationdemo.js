/**
 * Created by Sakthibalan Rm on 07/08/15.
 * Description:
 *
 */
define([
    'angular'
], function (angular) {
    angular.module('PaginationDemo', []);
});