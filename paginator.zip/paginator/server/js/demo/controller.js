/**
 * Created by Sakthibalan Rm on 07/08/15.
 * Description:
 *
 */
define([
    'angular',
    'server/js/demo/paginationdemo',
], function (angular,template) {
    angular.module('PaginationDemo')
    .controller('PaginationDemoController',['$scope',function($scope){
    	
    	$scope.details = [{"firstName":"Name 1","age":1},{"firstName":"Name 2","age":2},{"firstName":"Name 3","age":3},{"firstName":"Name 4","age":4},{"firstName":"Name 5","age":5},{"firstName":"Name 6","age":6},{"firstName":"Name 7","age":7},{"firstName":"Name 8","age":8},{"firstName":"Name 9","age":9},{"firstName":"Name 10","age":10},{"firstName":"Name 11","age":11},{"firstName":"Name 12","age":12},{"firstName":"Name 13","age":13},{"firstName":"Name 14","age":14},{"firstName":"Name 15","age":15},{"firstName":"Name 16","age":16},{"firstName":"Name 17","age":17},{"firstName":"Name 18","age":18},{"firstName":"Name 19","age":19},{"firstName":"Name 20","age":20},{"firstName":"Name 21","age":21},{"firstName":"Name 22","age":22},{"firstName":"Name 23","age":23},{"firstName":"Name 24","age":24},{"firstName":"Name 25","age":25},{"firstName":"Name 26","age":26},{"firstName":"Name 27","age":27},{"firstName":"Name 28","age":28},{"firstName":"Name 29","age":29},{"firstName":"Name 30","age":30}];
 		$scope.detailsList = [];   	
    	
    	$scope.currentPage = 0;
    	$scope.recordsPerPage = 5;
    	
    	$scope.totalPages = Math.ceil($scope.details.length / $scope.recordsPerPage);
		$scope.$watch('currentPage', function(currentPage) {
		    $scope.detailsList = [];
		    for (var i = $scope.recordsPerPage * $scope.currentPage; i < (($scope.recordsPerPage * (parseInt($scope.currentPage) + 1) > $scope.details.length) ? $scope.details.length : $scope.recordsPerPage * (parseInt($scope.currentPage) + 1)); i++) {
		        $scope.detailsList.push($scope.details[i]);
		    }
		});
        $scope.$watch('recordsPerPage', function(recordsPerPage) {
            $scope.detailsList = [];
            for (var i = $scope.recordsPerPage * $scope.currentPage; i < (($scope.recordsPerPage * (parseInt($scope.currentPage) + 1) > $scope.details.length) ? $scope.details.length : $scope.recordsPerPage * (parseInt($scope.currentPage) + 1)); i++) {
                $scope.detailsList.push($scope.details[i]);
            }
        });
    }]);
});

