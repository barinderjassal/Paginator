/**
 * Created by Leon Cutler on 11/12/14.
 * Description:
 *
 */

define([
    'angular',
    'text!server/js/demo/template.html',
    'server/js/demo/paginationdemo',
    'server/js/demo/controller'
], function(angular, template) {
    angular.module('PaginationDemo').directive('paginationDemoDirective', [function() {
        return {
            restrict: "AEC",
            required : 'paginationDirective',
            template: template,
            replace: false,
            controller: 'PaginationDemoController'
        };
    }]);
});
