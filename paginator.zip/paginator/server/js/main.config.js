require.config({
    baseUrl:'/',
    paths:{
        'angular': '/server/bower_components/angular/angular',
        'domready': '/server/bower_components/requirejs-domready/domReady',
        'text': '/server/bower_components/requirejs-text/text',
        'app': '/server/js/app',
        'headroom': '/server/bower_components/headroom.js/dist/headroom',
        'ngHeadroom': '/server/bower_components/headroom.js/dist/angular.headroom',
        'angularBootstrap': '/server/bower_components/angular-bootstrap/ui-bootstrap-tpls',
        'moduleLoader': '/module/js/loader',
        'demoloader': '/server/js/demo/loader'
    },
    shim:{
        angular: {exports: 'angular'},
        ngHeadroom: {
            deps: ['angular', 'headroom']
        },
        angularBootstrap: {
            deps: ['angular']
        },
        globalheader: {
            deps: ['angular']
        }
    }
});

require(['domready', 'angular', 'app'], function(domReady, angular){
    domReady(function(){
        angular.bootstrap(document, ['app']);
    });
});