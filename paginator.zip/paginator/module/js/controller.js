/**
 * Created by Leon Cutler on 11/12/14.
 * Description:
 *
 */

define([

    'angular',
    'module/js/pagination'

], function(angular) {
    angular.module('Pagination')
        .controller('PaginationController', ['$scope',
            function($scope) {
                $scope.view = {};
                $scope.count = [5, 10, 15, 20, 25, 30, 35, 40, 45, 50];
                $scope.previous = function() {
                    if ($scope.currentPage > 0) {
                        $scope.currentPage--;
                        $scope.display();
                    }
                };
                $scope.next = function() {
                    if ($scope.currentPage < $scope.totalPages - 1) {
                        $scope.currentPage++;
                        $scope.display();
                    }
                };
                $scope.first = function() {
                    if ($scope.currentPage > 0) {
                        $scope.currentPage = 0;
                        $scope.display();
                    }
                };
                $scope.last = function() {
                    if ($scope.currentPage < $scope.totalPages - 1) {
                        $scope.currentPage = $scope.totalPages - 1;
                        $scope.display();
                    }
                };
                $scope.goToPage = function(e) {
                    if (!!e.currentTarget) {
                        var pageNo = parseInt($scope.pageIndex);
                        if ($scope.pageIndex != '') {
                            if (!(isNaN(pageNo))) {
                                $scope.error = false;
                                $scope.lengthError = false;
                                pageNo--;
                                if (pageNo <= $scope.totalPages - 1 && pageNo >= 0) {
                                    $scope.currentPage = pageNo;
                                    $scope.display();
                                    if (e.currentTarget.tagName != 'FORM') {
                                        e.currentTarget.blur();
                                    } else {
                                        e.currentTarget.children[0].blur();
                                    }

                                } else {
                                    $scope.lengthError = true;
                                    if (e.currentTarget.tagName != 'FORM') {
                                        e.currentTarget.setSelectionRange(0, e.currentTarget.value.length);
                                    } else {
                                        e.currentTarget.children[0].setSelectionRange(0, e.currentTarget.children[0].value.length);
                                    }
                                }
                            } else {
                                $scope.lengthError = false;
                                $scope.error = true;
                                if (e.currentTarget.tagName != 'FORM') {
                                    e.currentTarget.setSelectionRange(0, e.currentTarget.value.length);
                                } else {
                                    e.currentTarget.children[0].setSelectionRange(0, e.currentTarget.children[0].value.length);
                                }
                            }
                        } else {
                            $scope.display();
                        }
                    }
                };
                $scope.display = function() {
                    $scope.lengthError = false;
                    $scope.error = false;
                    $scope.pageIndex = "Page " + (parseInt($scope.currentPage) + 1) + "/" + $scope.totalPages;
                };
                $scope.clearText = function(e) {
                    $scope.pageIndex = parseInt($scope.currentPage) + 1;
                };
                $scope.$watch('totalRecords', function(totalRecords) {
                    if (!!totalRecords) {
                        if ($scope.recordsPerPage == undefined) {
                            $scope.recordsPerPage = 5;
                        }
                        $scope.totalPages = Math.ceil(parseInt($scope.totalRecords) / parseInt($scope.recordsPerPage));
                        $scope.display();
                        $scope.currentPage = 0;
                    }
                });
                $scope.$watch('currentPage', function(currentPage) {
                    if (currentPage != undefined && currentPage != null) {
                        if ($scope.recordsPerPage == undefined) {
                            $scope.recordsPerPage = 5;
                        }
                        $scope.totalPages = Math.ceil(parseInt($scope.totalRecords) / parseInt($scope.recordsPerPage));
                        $scope.display();
                    }
                });
                $scope.$watch('recordsPerPage', function(recordsPerPage) {
                    if (!!recordsPerPage) {
                        $scope.totalPages = Math.ceil(parseInt($scope.totalRecords) / parseInt($scope.recordsPerPage));
                        $scope.recordsPerPage = parseInt(recordsPerPage);
                        $scope.display();
                        $scope.currentPage = 0;
                    }
                });
                $scope.$watch('noBoundaryLinks', function(noBoundaryLinks) {
                    if ((noBoundaryLinks != undefined && (noBoundaryLinks === '' || noBoundaryLinks)) === 'true') {
                        $scope.view.noBoundaryLinks = true;
                    } else {
                        $scope.view.noBoundaryLinks = false;
                    }
                });
                $scope.$watch('isDisabled', function(isDisabled) {
                    if ((isDisabled != undefined && (isDisabled === '' || isDisabled)) === 'true') {
                        $scope.view.disabled = true;
                    } else {
                        $scope.view.disabled = false;
                    }
                });
                $scope.$watch('noCountSelector', function(noCountSelector) {
                    if ((noCountSelector != undefined && (noCountSelector === '' || noCountSelector)) === 'true') {
                        $scope.view.noCountSelector = true;
                    } else {
                        $scope.view.noCountSelector = false;
                    }
                });
            }
        ]);
});
