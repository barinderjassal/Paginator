/**
 * Created by Leon Cutler on 11/12/14.
 * Description:
 *
 */

define([
    'angular',
    'text!module/template/template.html',
    'module/js/pagination',
    'module/js/controller'

], function(angular, template) {
    angular.module('Pagination').directive('paginationDirective', [function() {
        return {
            restrict: "AEC",
            scope: {
                totalRecords: '@',
                recordsPerPage: '=',
                currentPage: "=",
                isDisabled: '@',
                noBoundaryLinks: '@',
                noCountSelector: '@'
            },
            template: template,
            replace: false,
            controller: 'PaginationController',
            link: function(scope, element, attrs) {}
        };
    }]);
});
