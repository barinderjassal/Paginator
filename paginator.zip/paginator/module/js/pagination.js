/**
 * Created by Leon Cutler on 11/12/14.
 * Description:
 *
 */
define([
    'angular'
], function (angular) {
    angular.module('Pagination', []);
});