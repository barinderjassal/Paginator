var express = require('express'),
    bodyParser = require('body-parser'),
    engines = require('consolidate'),
    http = require('http'),
    url = require('url'),
    request = require('request');

var port_id = 8484;
var app = express();
/**
 * Is Empty - validate an JSON is empty
 * @param obj
 * @returns {boolean}
 */
function isEmpty(obj) {
    for ( var key in obj)
    {
        return false;
    }
    return true;
}
/**
 *  Express Configuration
 */
console.log(__dirname);
app.use(bodyParser.json());
app.use(express.static(__dirname));
app.use(express.static(__dirname + '/server'));
app.use(express.static(__dirname + '/module'));
app.set('views', __dirname+'/server');
app.use(express.Router());
app.engine('hbs', engines.handlebars);
app.set('view engine', 'hbs');
app.get('/', function(req, res){
        res.render('index');
    }
);
/**
 *
 *  Gatekeeper Proxy
 *
 */
app.all('/proxy/*', function(req, res) {
    res.set('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.set('Pragma', 'no-cache');
    res.set('Expires', 0);
    var base_url = req.url.replace('/proxy/', 'http://');
    var parts = url.parse(base_url, true);
    parts.query.access_token = config.gatekeeperToken;
    delete parts.search;
    var headers = {
        'host': parts.host,
        'accept': 'application/json, text/javascript, */*; q=0.01',
        'cookie': req.header('Cookie')
    };
    var options = {
        'uri': url.format(parts),
        'method': req.method,
        'headers': headers,
        'jar': false,
        'pool': false,
        'timeout': 20000
    };
    if(!isEmpty()){
        options.json = req.body;
    }
    var proxyReq = request(options, function(error, response, body){
        if(error){
            return res.send(response.statusCode, error);
        } else {
            return res.send(response.statusCode, body);
        }
    });
    proxyReq.on('error',function(){
        res.send(500, {error: 'failed to complete request'});
    });

});
/**
 *
 * Cross Site Proxy
 *
 */
app.all('/http_proxy/*', function(req, res) {
    res.set('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.set('Pragma', 'no-cache');
    res.set('Expires', 0);
    var base_url = req.url.replace('/http_proxy/', 'http://');
    var parts = url.parse(base_url, true);
    var headers = {
        'host': parts.host,
        'accept': 'application/json, text/javascript, */*; q=0.01, text/html',
        'cookie': req.header('Cookie')
    };
    var options = {
        'uri': url.format(parts),
        'method': req.method,
        'headers': headers,
        'jar': false,
        'pool': false,
        'timeout': 20000
    };

    var proxyReq = request(options, function(error, response, body){
        if(error){
            return res.send(500, error);
        } else {
            return res.send(200, body);
        }
    });
    proxyReq.on('error',function(){
        res.send(500, {error: 'failed to complete request'});
    });

});

http.createServer(app);

app.listen(port_id, '0.0.0.0');

console.log('Module Test Server is now Starting on port ' + port_id);