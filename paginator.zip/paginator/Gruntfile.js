module.exports = function(grunt){

    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        less: {
            dev: {
                options:{
                    paths: ['less'],
                    ieCompat: true
                },
                files:{
                    'server/css/main.css': 'server/less/main.less'
                }
            }
        },
        requirejs: {
            build: {
                options: {
                    dir: "./build/js",
                    //baseUrl: "/server/public/js",
                    mainConfigFile: "./server/js/main.config.js",
                    optimize: "none",
                    generateSourceMaps: false,
                    preserveLicenseComments: false,
                    locale: "en-us",
                    skipDirOptimize: false, //Skip non-build bundles
                    optimizeAllPluginResources: false,
                    inlineText: true, // Adds all HTML Text (Text!) inline so we dont need to load templates
                    removeCombined: true, //Break down build bundles and remove from output folder
                    modules: [
                        {
                            name: 'main.config',
                            include: [
                                'angular',
                                'ngHeadroom',
                                'angularBootstrap',
                                'globalheader'
                            ]
                        }
                    ]
                }
            },
            module: {
                options: {
                    out: "./build/module.build.js",
                    baseUrl: './',
                    mainConfigFile: "./server/js/main.config.js",
                    include: ['./module/js/loader'],
                    insertRequired: ['./module/js/loader'],
                    optimize: "none",
                    skipModuleInsertion: true,
                    onModuleBundleComplete: function (data) {
                        var fs = module.require('fs'),
                            amdclean = module.require('amdclean'),
                            outputFile = data.path,
                            cleanedCode = amdclean.clean({
                                'filePath': outputFile,
                                transformAMDChecks: false,
                                removeModules: ['angular', 'text']
                            });
                        fs.writeFileSync(outputFile, cleanedCode);
                    },
                    generateSourceMaps: false,
                    preserveLicenseComments: false,
                    locale: "en-us",
                    inlineText: true, // Adds all HTML Text (Text!) inline so we dont need to load templates
                    paths: {
                        angular: "empty:",
                        'text': './server/bower_components/requirejs-text/text',
                    }
                }
            }
        },
        uglify: {
            built: {
                options: {
                    mangle: false,
                    compress: true,
                    report: 'min'
                },
                files: {
                    './build/js/main.js': ['./build/js/main.config.js']
                }
            }
        },
        jshint: {
            local: {
                files: [
                    {
                        expand: true,
                        cwd: './module/js/',
                        src: [
                            '**/*.js',
                            '!lib/**',
                            '!**/lib/**',
                            '!server/bower_components/**',
                            '!server/js/**',
                        ]
                    }
                ],
                options: {
                    jshintrc: '.jshintrc',
                    force: true,
                    reporter: 'checkstyle',
                    reporterOutput: 'tests/reports/jshint/jshint-result.xml'
                }
            }
        }
    });


    grunt.loadNpmTasks('grunt-contrib-less');

    grunt.loadNpmTasks('grunt-contrib-jshint');

    grunt.loadNpmTasks('grunt-contrib-requirejs');

    grunt.loadNpmTasks('grunt-contrib-uglify');

    grunt.registerTask('dev', ['less:dev']);

    grunt.registerTask('require', ['requirejs:build']);

    grunt.registerTask('buildmodule', ['requirejs:module']);

    grunt.registerTask('uglifier', ['uglify:built']);

    grunt.registerTask('build', ['less:dev', 'requirejs:build', 'uglify:built', 'jshint:local']);

    grunt.registerTask('hint', ['jshint:local']);

    grunt.registerTask('jenkins', ['less:dev','jshint:jenkins']);

};